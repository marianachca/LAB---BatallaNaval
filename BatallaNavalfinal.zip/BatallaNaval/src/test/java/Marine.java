public class Marine {
    private String name;
    private int range;
}
