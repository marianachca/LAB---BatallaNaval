public class AirCraftCarrier {
    private int numberId;
    private int capacity;
    private int tripulantes;
    private int puntaje;
    private Position pos;

    AirCraftCarrier(int id, int capacidad) {
        numberId = id;
        capacity = capacidad;
        tripulantes = 0;
        puntaje = 0;
        this.pos = pos;
    }

    AirCraftCarrier(int id, int capacidad, Position pos) {
        new AirCraftCarrier(id, capacidad);
        this.pos = pos;
    }

    public int getCapacity() {
        return capacity;
    }

    public Position getPos() {
        return pos;
    }
}
