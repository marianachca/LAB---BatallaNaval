public class AirCraft {
    private String licencePlate;
    private boolean inAir;
    private Position pos;

    public AirCraft(String licence, boolean enAire) {
        licencePlate = licence;
        inAir = enAire;
        this.pos = pos;
    }

    public AirCraft(String licence, boolean enAire, Position pos) {
        new AirCraft(licence, enAire);
        this.pos = pos;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public boolean getInAir() {
        return inAir;
    }

    public Position getPos() {
        return pos;
    }
}
