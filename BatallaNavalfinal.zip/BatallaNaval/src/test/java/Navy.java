import java.util.ArrayList;
import java.util.Collections;

public class Navy {
    // Atributos
    private int code;
    private String name;
    private ArrayList<AirCraft> arrAirCraft = new ArrayList();
    private ArrayList<AirCraftCarrier> arrAirCraftCarrier = new ArrayList();
    private ArrayList<Ship> arrShip = new ArrayList();
    private ArrayList<Marine> arrMarine = new ArrayList();

    // Constructor con parámetro de nombre
    public Navy(String nombre) {
        name = nombre;
    }

    public String getName() {
        return name;
    }

    public ArrayList<AirCraft> getArrAirCraft() {
        return arrAirCraft;
    }

    public ArrayList<Ship> getArrShip() {
        return arrShip;
    }

    public ArrayList<Marine> getArrMarine() {
        return arrMarine;
    }

    public ArrayList<String> enAire() {
        ArrayList<String> arrPlacas = new ArrayList<String>();

        for (int i = 0; i < arrAirCraft.size(); i++) {
            if (arrAirCraft.get(i).getInAir()) {
                arrPlacas.add(arrAirCraft.get(i).getLicencePlate());
            }
        }
        Collections.sort(arrPlacas);
        return arrPlacas;
    }

    public boolean posicionPropia(int longitud, int latitud) {
        boolean posPropia = false;

        for(int i = 0; i < arrAirCraft.size(); i++)
            if (arrAirCraft.get(i).getPos().getLatitude() == latitud &&
                    arrAirCraft.get(i).getPos().getLongitude() == longitud)
                posPropia = true;

        for(int i = 0; i < arrAirCraftCarrier.size(); i++)
            if (arrAirCraftCarrier.get(i).getPos().getLatitude() == latitud &&
                    arrAirCraftCarrier.get(i).getPos().getLongitude() == longitud)
                posPropia = true;

        for(int i = 0; i < arrShip.size(); i++)
            if (arrShip.get(i).getPos().getLatitude() == latitud &&
                    arrShip.get(i).getPos().getLongitude() == longitud)
                posPropia = true;

        return posPropia;
    }

    public boolean esBuenAtaque(int longitud, int latitud) {
        return !posicionPropia(longitud, latitud);
    }

    public void muevase(int deltaLongitud, int deltaLatitud) {
        boolean seMueven = true;
        for(int i = 0; i < arrShip.size(); i++) {
            if (Math.abs(arrShip.get(i).getPos().getLongitude() + deltaLongitud) > 100 ||
                 Math.abs(arrShip.get(i).getPos().getLatitude() + deltaLatitud) > 100)
                System.out.println("Se salen del mapa");
            else {
                arrShip.get(i).getPos().setPosition(arrShip.get(i).getPos().getLatitude() + deltaLatitud,
                        arrShip.get(i).getPos().getLongitude() + deltaLongitud);
            }
        }
    }

    public boolean puedenMoverse(int deltaLongitud, int deltaLatitud) {
        boolean seMueven = true;
        for(int i = 0; i < arrShip.size(); i++) {
            if (Math.abs(arrShip.get(i).getPos().getLongitude() + deltaLongitud) > 100 ||
                    Math.abs(arrShip.get(i).getPos().getLatitude() + deltaLatitud) > 100)
                seMueven = false;
        }
        return seMueven;
    }

    public int numeroMaquinas() {
        return arrAirCraft.size() + arrAirCraftCarrier.size() + arrShip.size();
    }

    public boolean suficientesMarinos() {
        return (arrMarine.size() >= arrShip.size() * 4 + arrAirCraft.size() * 2 + arrAirCraftCarrier.size() * 5);
    }

    public ArrayList<Object> seranDestruidas(int longitud, int latitud) {
        ArrayList<Object> maquinasADestruir = new ArrayList<Object>();

        for (int i = 0; i < arrAirCraft.size(); i++)
            if (arrAirCraft.get(i).getPos().getLongitude() == longitud && arrAirCraft.get(i).getPos().getLatitude() == latitud) {
                maquinasADestruir.add(arrAirCraft.get(i));
            }

        for (int i = 0; i < arrAirCraftCarrier.size(); i++)
            if (arrAirCraftCarrier.get(i).getPos().getLongitude() == longitud && arrAirCraftCarrier.get(i).getPos().getLatitude() == latitud) {
                maquinasADestruir.add(arrAirCraftCarrier.get(i));
            }

        for (int i = 0; i < arrShip.size(); i++)
            if (arrShip.get(i).getPos().getLongitude() == longitud && arrShip.get(i).getPos().getLatitude() == latitud) {
                maquinasADestruir.add(arrShip.get(i));
            }

        return maquinasADestruir;
    }
}
