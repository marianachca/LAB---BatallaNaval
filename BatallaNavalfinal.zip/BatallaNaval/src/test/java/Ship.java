public class Ship {
    private int numberId;
    private Position pos;

    public Ship(int numberId, Position pos) {
        this.numberId = numberId;
        this.pos = pos;
    }

    public Position getPos() {
        return pos;
    }


}
