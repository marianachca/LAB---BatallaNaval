import org.junit.Test;
import java.util.ArrayList;
import java.util.Collections;
import static org.junit.Assert.assertEquals;

public class BatallaNavalTest {
    @Test
    public void testAlias() throws Exception {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        battleNavy.addNavy("LA GRAN ARMADA DE CASTILLA");

        assertEquals(0, battleNavy.alias());
    }
    @Test
    public void testdisponibilidadEnPortaAviones() throws Exception {
        AirCraftCarrier airtcraftcarrier = new AirCraftCarrier(102, 2);
        assertEquals(4, airtcraftcarrier.getCapacity());
    }
    @Test
    public void testEnemigosEnAire() throws Exception {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        battleNavy.addNavy("LA GRAN ARMADA DE CASTILLA");
        AirCraft avionA = new AirCraft("AQ12", true);
        AirCraft avionB = new AirCraft("AQ14", true);

        int enemy = 0;
        battleNavy.getArrNavy().get(enemy).getArrAirCraft().add(avionA);
        battleNavy.getArrNavy().get(enemy).getArrAirCraft().add(avionB);

        ArrayList<String> respValida = new ArrayList<String>();
        respValida.add("AQ14"); respValida.add("AQ12");

        Collections.sort(respValida);
        assertEquals(respValida, battleNavy.getArrNavy().get(enemy).enAire());
    }
    @Test
    public void testEsBuenAtaque() throws Exception {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        battleNavy.addNavy("LA GRAN ARMADA DE CASTILLA");
        AirCraft avionA = new AirCraft("AQ12", true, new Position(100, 30));
        AirCraft avionB = new AirCraft("AQ14", true, new Position(10, 70));
        Ship barcoA = new Ship(23, new Position(56, 56));

        int team = 1, enemy = 0;
        battleNavy.getArrNavy().get(team).getArrAirCraft().add(avionA);
        battleNavy.getArrNavy().get(enemy).getArrAirCraft().add(avionB);
        battleNavy.getArrNavy().get(enemy).getArrShip().add(barcoA);

        assertEquals(true, battleNavy.getArrNavy().get(team).esBuenAtaque(30, 100));
        //assertEquals(false, battleNavy.getArrNavy().get(enemy).esBuenAtaque(70, 10));
    }
    @Test
    public void testMuevase() {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        Ship barcoA = new Ship(23, new Position(56, 56));
        int team = 0;
        battleNavy.getArrNavy().get(team).getArrShip().add(barcoA);
        battleNavy.getArrNavy().get(team).muevase(45, 34);

        assertEquals(true, battleNavy.getArrNavy().get(team).puedenMoverse(30, 10));
    }
    @Test
    public void testnumeroMaquinas() {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        Ship barcoA = new Ship(23, new Position(56, 56));

        int team = 0;
        battleNavy.getArrNavy().get(team).getArrShip().add(barcoA);

        assertEquals(2, battleNavy.getArrNavy().get(team).numeroMaquinas());
    }
    @Test
    public void testProblemaEnAire() {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        battleNavy.addNavy("LA GRAN ARMADA DE CASTILLA");
        AirCraft avionA = new AirCraft("AQ12", true);
        AirCraft avionB = new AirCraft("AQ14", true);

        int team = 0, enemy = 1;
        battleNavy.getArrNavy().get(team).getArrAirCraft().add(avionA);
        battleNavy.getArrNavy().get(enemy).getArrAirCraft().add(avionB);

        assertEquals(true, battleNavy.problemaEnAire());
    }
    @Test
    public void testMarinosSufientes() {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        AirCraft avionA = new AirCraft("AQ12", true);
        AirCraft avionB = new AirCraft("AQ14", true);

        int team = 0;
        Marine marinoA = new Marine();
        Marine marinoB = new Marine();

        battleNavy.getArrNavy().get(team).getArrAirCraft().add(avionA);
        battleNavy.getArrNavy().get(team).getArrMarine().add(marinoA);
        battleNavy.getArrNavy().get(team).getArrMarine().add(marinoB);

        assertEquals(false, battleNavy.getArrNavy().get(team).suficientesMarinos());
    }
    @Test
    public void testMaquinasADestruir() {
        BatallaNaval battleNavy = new BatallaNaval();

        battleNavy.addNavy("LA GRAN FLOTA BLANCA");
        battleNavy.addNavy("LA GRAN ARMADA DE CASTILLA");
        AirCraft avionA = new AirCraft("AQ12", true, new Position(100, 30));
        AirCraft avionB = new AirCraft("AQ14", true, new Position(10, 70));
        Ship barcoA = new Ship(23, new Position(56, 59));

        int team = 1, enemy = 0;
        battleNavy.getArrNavy().get(team).getArrAirCraft().add(avionA);
        battleNavy.getArrNavy().get(enemy).getArrAirCraft().add(avionB);
        battleNavy.getArrNavy().get(enemy).getArrShip().add(barcoA);

        ArrayList<Object> arrtoDestroyEsperado = new ArrayList<Object>();
        arrtoDestroyEsperado.add(barcoA);

        assertEquals(arrtoDestroyEsperado, battleNavy.getArrNavy().get(enemy).seranDestruidas(56, 56));
    }
}
