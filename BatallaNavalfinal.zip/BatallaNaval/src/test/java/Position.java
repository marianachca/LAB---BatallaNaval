public class Position {
    private int latitude;
    private int longitude;

    public Position(int latitud, int longitud) {
        setPosition(latitud, longitud);
    }

    public void setPosition(int latitud, int longitud) {
        latitude = latitud;
        longitude = longitud;
    }

    public int getLatitude() {
        return latitude;
    }

    public int getLongitude() {
        return longitude;
    }
}
