import java.util.ArrayList;

public class BatallaNaval {
    private ArrayList<Navy> arrNavy = new ArrayList();

    public ArrayList<Navy>getArrNavy() {
        return arrNavy;
    }

    public void addNavy(String name) {
        arrNavy.add(new Navy(name));
    }

    public int alias() {
        if (arrNavy.get(0).getName() == arrNavy.get(1).getName())
            return 1;
        else
            return 0;
    }

    public boolean problemaEnAire() {
        boolean hayProblema = false;
        for (int i = 0; i < arrNavy.get(0).getArrAirCraft().size(); i++)
            for (int j = 0; j < arrNavy.get(1).getArrAirCraft().size(); j++)
                if (arrNavy.get(0).getArrAirCraft().get(i).getLicencePlate() == arrNavy.get(1).getArrAirCraft().get(j).getLicencePlate()) {
                    hayProblema = true;
                }
        return hayProblema;
    }
}
